/* Daily board, rumor, derby. Seeded per in-game day. */

const Quests = {
  open: false,

  rollDay() {
    const rng = Save.dayRng("quests");
    const ask = Utils.pick(rng, DAILY_ASKS);
    Save.data.quests.daily = {
      day: Save.data.clock.day,
      fish: ask.fish,
      spot: ask.spot,
      text: ask.text,
      done: false,
    };
    const rumorFish = FISH.filter((f) => f.rarity === "Rare" || f.rarity === "Uncommon");
    let rf = Utils.pick(rng, rumorFish);
    if (Skills.rank() >= 6 && rng() < 0.55) {
      const night = FISH.filter((f) => f.nightOnly);
      if (night.length) rf = Utils.pick(rng, night);
    }
    Save.data.quests.rumor = {
      day: Save.data.clock.day,
      fish: rf.id,
      spot: rf.spot,
      text: `${rf.name} was seen at ${SPOTS[rf.spot].name}.`,
    };
    const now = new Date();
    const weekend = now.getDay() === 0 || now.getDay() === 6;
    const fest = (Save.data.clock.day % 7) === 0;
    const key = weekend ? `w-${now.getFullYear()}-${now.getMonth()}-${now.getDate()}` : (fest ? `d-${Save.data.clock.day}` : "");
    if (key && Save.data.quests.derby.key !== key) {
      Save.data.quests.derby = { key, mood: rng() < 0.5 ? "still" : "moving", landed: 0, goal: 8 };
    }
    if (!key) Save.data.quests.derby.key = "";
    MillSpine.tickHeard();
    this._biasRumor(rng);
  },

  _biasRumor(rng) {
    const spine = MillSpine.stage();
    if (spine !== "heard" && spine !== "opened" && spine !== "visited") return;
    if (rng() >= 0.5) return;
    if (Save.data.flags.fifthWater) {
      const marsh = FISH.filter((f) => f.spot === "marsh");
      if (!marsh.length) return;
      const rf = Utils.pick(rng, marsh);
      Save.data.quests.rumor = {
        day: Save.data.clock.day,
        fish: rf.id,
        spot: rf.spot,
        text: `${rf.name} was seen at ${SPOTS[rf.spot].name}.`,
      };
      return;
    }
    Save.data.quests.rumor = {
      day: Save.data.clock.day,
      fish: "",
      spot: "marsh",
      text: MILL_SPINE_RUMOR_QUIET,
    };
  },

  onLand(fish) {
    let bonus = false;
    const d = Save.data.quests.daily;
    if (d && !d.done && fish.id === d.fish) {
      d.done = true;
      Inventory.addCoins(DESIGN.dailyCoins);
      Inventory.addBait("worms", DESIGN.dailyWorms);
      Save.data.npcs.wren.hearts = Math.min(DESIGN.npcHeartCap, (Save.data.npcs.wren.hearts | 0) + 1);
      UI.toastNote("Daily board complete. Wren is pleased.");
      Save.mark("quest");
      bonus = true;
    }
    const der = Save.data.quests.derby;
    if (der && der.key && SPOTS[fish.spot] && SPOTS[fish.spot].mood === der.mood) {
      der.landed = (der.landed | 0) + 1;
      bonus = true;
    }
    const rumor = Save.data.quests.rumor;
    if (rumor && fish.id === rumor.fish) {
      UI.toastNote("The rumor was true.");
      bonus = true;
    }
    MillSpine.onMillfin(fish);
    return bonus;
  },

  dailyLine() {
    const d = Save.data.quests.daily;
    if (!d || !d.fish) return "No board posted yet.";
    if (d.done) return "Today’s board is done.";
    return d.text;
  },

  rumorLine() {
    const r = Save.data.quests.rumor;
    return (r && r.text) || "The water is keeping its secrets.";
  },

  derbyLine() {
    const d = Save.data.quests.derby;
    if (!d || !d.key) return "";
    return `Derby: land ${d.goal} ${d.mood}-water fish (${d.landed}/${d.goal}).`;
  },

  toggle() {
    this.open = !this.open;
    const el = document.getElementById("board");
    if (!el) return;
    el.classList.toggle("hidden", !this.open);
    if (this.open) this.refresh();
    else Save.mark();
  },

  close() {
    if (!this.open) return;
    this.open = false;
    const el = document.getElementById("board");
    if (el) el.classList.add("hidden");
  },

  refresh() {
    const el = document.getElementById("board-body");
    if (!el) return;
    const f = (Save.data.clock.forecast || []).map((id) => WEATHERS[id].name).join(" → ");
    el.innerHTML = `
      <p><strong>Today</strong> — ${this.dailyLine()}</p>
      <p><strong>Rumor</strong> — ${this.rumorLine()}</p>
      <p><strong>Forecast</strong> — ${f}</p>
      <p><strong>Hotspot</strong> — ${SPOTS[TimeCycle.hotspot()].name} is alive today.</p>
      ${this.derbyLine() ? `<p><strong>Derby</strong> — ${this.derbyLine()}</p>` : ""}`;
  },
};

const Board = Quests;

const MillSpine = {
  _order: ["none", "heard", "opened", "visited", "done"],

  stage() {
    return (Save.data && Save.data.flags && Save.data.flags.millSpine) || "none";
  },

  atLeast(step) {
    return this._order.indexOf(this.stage()) >= this._order.indexOf(step);
  },

  _set(step) {
    if (this.atLeast(step)) return false;
    Save.data.flags.millSpine = step;
    return true;
  },

  keepFive() {
    return this.stage() !== "none";
  },

  mailCap() {
    return this.keepFive() ? 5 : 3;
  },

  pushLetter(beat) {
    const text = MILL_SPINE_MAIL[beat];
    if (!text || !Save.data || !Save.data.cottage) return;
    let mail = Save.data.cottage.mail;
    if (!Array.isArray(mail)) mail = Save.data.cottage.mail = [];
    const at = mail.indexOf(text);
    if (at >= 0) mail.splice(at, 1);
    mail.unshift(text);
    Save.data.cottage.mail = mail.slice(0, this.mailCap());
  },

  tickHeard() {
    if (!Save.data) return;
    if (this.stage() !== "none") return;
    if (!Save.data.cottage.visited) return;
    if ((Save.data.clock.day | 0) < 2) return;
    this._set("heard");
    this.pushLetter("heard");
    Save.mark();
  },

  onOpened() {
    if (!Save.data || !Save.data.flags.fifthWater) return;
    if (this.atLeast("opened")) return;
    this._set("opened");
    this.pushLetter("opened");
    UI.toastNote("The east boat is free. The mill is still silent.");
    Save.mark();
  },

  onVisited() {
    if (typeof World === "undefined" || World.id !== "marsh") return;
    if (!this.atLeast("heard")) return;
    if (this.atLeast("visited")) return;
    this._set("visited");
    this.pushLetter("visited");
    Save.mark();
  },

  onMillfin(fish) {
    if (!fish || fish.id !== "millfin") return;
    if (!this.atLeast("visited")) return;
    if (this.stage() === "done") return;
    this._set("done");
    this.pushLetter("done");
    UI.toastNote("The mill keeps its silence — but you were there.");
    try { if (typeof Stamps !== "undefined") Stamps.try("millQuiet"); } catch (e) { /* stamp optional */ }
    try { if (typeof Island !== "undefined") Island.onQuiet(); } catch (e) { /* island optional */ }
    Save.mark();
  },
};

const Mail = {
  open: false,
  toggle() {
    this.open = !this.open;
    const el = document.getElementById("mail");
    if (!el) return;
    el.classList.toggle("hidden", !this.open);
    if (this.open) {
      MillSpine.tickHeard();
      this.refresh();
    }
    else Save.mark();
  },
  close() {
    if (!this.open) return;
    this.open = false;
    const el = document.getElementById("mail");
    if (el) el.classList.add("hidden");
  },
  refresh() {
    const el = document.getElementById("mail-body");
    if (!el) return;
    const notes = Save.data.cottage.mail || [];
    if (!notes.length) el.innerHTML = "<p>The tray is empty.</p>";
    else el.innerHTML = notes.map((n) => `<p>${n}</p>`).join("");
  },
  generateAway() {
    const notes = [];
    notes.push(Quests.rumorLine());
    notes.push("Wren restocked worms and a little glow.");
    const last = Save.data.player.lastCatchName;
    if (last) notes.push(`Lark: “Still thinking about that ${last}.”`);
    else notes.push("Bramble left a note: the pond missed you.");
    const rec = (Save.data.recap || []).find((r) => r.reason === "passout");
    if (rec) notes.unshift("Wren: I found you in the reeds last night. The kettle’s still warm.");
    if ((Save.data.skills.rank | 0) > 1) notes.push(`Someone pinned a scrap: fisher rank ${Save.data.skills.rank}.`);
    if (typeof Cottage !== "undefined" && !Cottage.hasSlot("shelf")) {
      notes.push("Wren: cottage goods on the counter — a wall shelf if you have forty coins.");
    }
    MillSpine.tickHeard();
    Save.data.cottage.mail = notes.slice(0, MillSpine.mailCap());
    const mail = Save.data.cottage.mail;
    const beats = ["heard", "opened", "visited", "done"];
    for (let i = 0; i < beats.length; i++) {
      const beat = beats[i];
      if (!MillSpine.atLeast(beat)) continue;
      const text = MILL_SPINE_MAIL[beat];
      if (!text) continue;
      const at = mail.indexOf(text);
      if (at >= 0) mail.splice(at, 1);
      mail.unshift(text);
    }
    Save.data.cottage.mail = mail.slice(0, MillSpine.mailCap());
    Save.data.cottage.weeds = 4 + (Save.dayRng("weeds")() * 4) | 0;
  },
};

(function _millSpineMapEnter() {
  if (typeof World === "undefined" || !World.use) return;
  const orig = World.use.bind(World);
  World.use = function (id) {
    const prev = World.id;
    orig(id);
    try {
      if (id === "marsh" && prev !== "marsh" && typeof MillSpine !== "undefined") MillSpine.onVisited();
    } catch (err) { /* warp still works if mail flavor fails */ }
  };
})();
